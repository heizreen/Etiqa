export class Freelancer {
    _id: string;
    username!: string;
    email!: string;
    mobile!: string;
    skillsets!: string;
    hobby!: string;

}
