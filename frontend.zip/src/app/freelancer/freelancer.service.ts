import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs'

import {Freelancer} from './freelancer.model'

@Injectable({
  providedIn: 'root'
})
export class FreelancerService {
  FreelancersList!: Freelancer;
  freelancers!: Freelancer[];
  readonly baseURL = 'http://localhost:4000/api/freelancers';

  constructor(private http: HttpClient) { }

  postFreelancer(emp: Freelancer) {
    return this.http.post(this.baseURL, emp);
  }

  getFreelancerList() {
    return this.http.get(this.baseURL);
  }

  getFreelancer(_id: string) {
    return this.http.get(this.baseURL + `/${_id}`);
  }

  putFreelancer(emp: Freelancer) {
    return this.http.put(this.baseURL + `/${emp._id}`, emp);
  }

  deleteFreelancer(_id: string) {
    return this.http.delete(this.baseURL + `/${_id}`);
  }
}
