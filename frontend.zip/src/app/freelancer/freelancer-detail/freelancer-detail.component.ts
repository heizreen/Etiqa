import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FreelancerService } from '../freelancer.service';
import { Freelancer } from '../freelancer.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-freelancer-detail',
  templateUrl: './freelancer-detail.component.html',
  styleUrls: ['./freelancer-detail.component.scss']
})
export class FreelancerDetailComponent {
  freelancer: Freelancer;
  public freelancerForm: FormGroup;
  
  constructor(
    private freelancerService: FreelancerService, 
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private router: Router
    ) {
    this.freelancerForm = formBuilder.group({
      _id: ['', [Validators.required]],
      username: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, , Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      skillsets: ['', [Validators.required]],
      hobby: ['', [Validators.required]]
    })
  }

  ngOnInit() {
    let id = this.activatedRoute.snapshot.paramMap.get('id');

    if (id != null){
      this.freelancerService.getFreelancer(id).subscribe((res: any) => {
        this.freelancer = res;
        this.freelancerForm.patchValue({
          _id: this.freelancer._id,
          username: this.freelancer.username,
          email: this.freelancer.email,
          mobile: this.freelancer.mobile,
          skillsets: this.freelancer.skillsets,
          hobby: this.freelancer.hobby
        });
        console.log(this.freelancer)
      });
    }
  }

  onSubmit(){
    this.freelancerService.putFreelancer(this.freelancerForm.value).subscribe((res: any) => {
      this.resetForm();
      this.router.navigate(['/'])
    })
  }
  
  resetForm() {
    this.freelancerForm.reset();
  }

  goToListPage(){
    this.router.navigate(['/'])
  }
}
