import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FreelancerComponent } from './freelancer.component'
import { FreelancerDetailComponent } from './freelancer-detail/freelancer-detail.component';
import { FreelancerCreationComponent } from './freelancer-creation/freelancer-creation.component';

const routes: Routes = [
  {path: '' , component: FreelancerComponent},
  {path: 'update/:id' , component: FreelancerDetailComponent},
  {path: 'create' , component: FreelancerCreationComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FreelancerRoutingModule { }
