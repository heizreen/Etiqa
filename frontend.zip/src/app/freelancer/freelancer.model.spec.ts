import { Freelancer } from './freelancer.model';

describe('Freelancer', () => {
  it('should create an instance', () => {
    expect(new Freelancer()).toBeTruthy();
  });
});
