import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
 
import { FreelancerRoutingModule } from './freelancer.routing.module';
import { FreelancerComponent } from './freelancer.component';
import { FreelancerDetailComponent } from './freelancer-detail/freelancer-detail.component';
import { FreelancerCreationComponent } from './freelancer-creation/freelancer-creation.component';
 
@NgModule({
  declarations: [FreelancerComponent, FreelancerDetailComponent, FreelancerCreationComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule ,
    FreelancerRoutingModule,
  ],
  providers: [],
})
export class FreelancerModule { }