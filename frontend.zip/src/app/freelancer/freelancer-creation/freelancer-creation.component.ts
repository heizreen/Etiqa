import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { FreelancerService } from '../freelancer.service';
import { Freelancer } from '../freelancer.model';
import { Router } from '@angular/router';

declare var M: any;

@Component({
  selector: 'app-freelancer-creation',
  templateUrl: './freelancer-creation.component.html',
  styleUrls: ['./freelancer-creation.component.scss'],
  providers: [FreelancerService]
})
export class FreelancerCreationComponent {
  public freelancerForm: FormGroup;
  freelancer: Freelancer[];

  constructor(
    private freelancerService: FreelancerService, 
    private formBuilder: FormBuilder,
    private router: Router
    ) {
    this.freelancerForm = formBuilder.group({
      username: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      mobile: ['', [Validators.required, , Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
      skillsets: ['', [Validators.required]],
      hobby: ['', [Validators.required]]
    })
  }

  ngOnInit() {
    this.resetForm();
  }

  resetForm() {
    this.freelancerForm.reset();
  }

  onSubmit(){
    this.freelancerService.postFreelancer(this.freelancerForm.value).subscribe((res: any) => {
      this.resetForm();
      this.router.navigate(['/'])
    })
  }

  goToListPage(){
    this.router.navigate(['/'])
  }
}
