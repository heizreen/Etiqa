import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FreelancerCreationComponent } from './freelancer-creation.component';

describe('FreelancerCreationComponent', () => {
  let component: FreelancerCreationComponent;
  let fixture: ComponentFixture<FreelancerCreationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FreelancerCreationComponent]
    });
    fixture = TestBed.createComponent(FreelancerCreationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
