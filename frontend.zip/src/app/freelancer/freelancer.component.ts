import { Component, OnInit } from '@angular/core';
// import { NgForm } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { FreelancerService } from './freelancer.service';
import { Freelancer } from './freelancer.model';
import { Router } from '@angular/router';

declare var M: any;

@Component({
  selector: 'app-freelancer',
  templateUrl: './freelancer.component.html',
  styleUrls: ['./freelancer.component.scss'],
  providers: [FreelancerService]
})
export class FreelancerComponent implements OnInit{
  freelancer: Freelancer[];

  constructor(
    private freelancerService: FreelancerService, 
    private router: Router
    ) {}

  ngOnInit() {
    this.refreshFreelancerList();
  }

  refreshFreelancerList() {
    this.freelancerService.getFreelancerList().subscribe((res: any) => {
      this.freelancer = res as Freelancer[];
    });
  }

  onEdit(id: string) {
    this.router.navigate(['/update/' + id])
  }

  onDelete(_id: string) {
    if (confirm('Are you sure to delete this record ?') == true) {
      this.freelancerService.deleteFreelancer(_id).subscribe((res: any) => {
        this.refreshFreelancerList();
        M.toast({ html: 'Deleted successfully', classes: 'rounded' });
      });
    }
  }

  goToCreationPage(){
    this.router.navigate(['/create'])
  }
}
